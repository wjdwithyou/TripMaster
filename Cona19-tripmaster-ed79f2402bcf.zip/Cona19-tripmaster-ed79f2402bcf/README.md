# NodeJs Server Sources used for Hanyang SW Creation Contest.
### Job ###

* Captain : Lee hyuk-ho
* Vice-Captain : Jeong seung-chul
* Surplus Person : Oh hyeon-seok