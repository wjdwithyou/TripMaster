﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace BOM_Remover
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        // 폴더 선택 단추

        private void Button_FolderName_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            DialogResult result = dialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                FolderName.Text = dialog.SelectedPath;
            }
        }

        // 시작 단추

        private void Button_Start_Click(object sender, EventArgs e)
        {
            // 확장자 목록 정리

            List<string> extensions = new List<string>();
            string[] extensions_raw = ExtensionList.Text.Split(',');
            foreach (string extension_raw in extensions_raw)
            {
                string ext = "." + extension_raw.Trim().ToLower();
                if (extensions.Contains(ext)) continue;
                extensions.Add(ext);
            }

            // 테스트모드인지 확인

            bool testmode = IsTestMode.Checked;

            // 폴더 존재여부 확인

            if (!Directory.Exists(FolderName.Text))
            {
                MessageBox.Show("폴더가 존재하지 않습니다.");
                return;
            }

            // DirectoryInfo 객체 생성

            DirectoryInfo dir = new DirectoryInfo(FolderName.Text);

            // 로그 비우기

            ActivityLog.Items.Clear();

            // 작업 실행

            int items = WalkDirectoryTree(dir, extensions, StatusDisplay, ActivityLog, testmode);

            // 작업 완료 메시지 표시

            if (testmode)
            {
                StatusDisplay.Text = "테스트가 완료되었습니다. BOM 제거 대상 파일은 " + items + "개입니다.";
            }
            else
            {
                StatusDisplay.Text = "작업이 완료되었습니다. " + items + "개의 파일에서 BOM을 제거하였습니다.";
            }
        }

        // 작업에 사용되는 함수

        private static int WalkDirectoryTree(DirectoryInfo dir, List<string> extensions, Label status, ListBox log, bool testmode)
        {
            // 로그 자동스크롤에 사용되는 변수

            int visibleItems = log.ClientSize.Height / log.ItemHeight;

            // 처리된 파일 수를 기억

            int processedItems = 0;

            // 상태 표시

            status.Text = "작업 중: " + dir.FullName;
            Application.DoEvents();

            // 파일 및 서브폴더 목록을 저장할 변수들

            FileInfo[] files = null;
            DirectoryInfo[] subdirs = null;

            // 파일 목록을 구한다

            try
            {
                files = dir.GetFiles("*.*");
            }
            
            // 예외 처리
            
            catch (UnauthorizedAccessException)
            {
                log.Items.Add("접근 권한 없음: " + dir.FullName);
                log.TopIndex = Math.Max(log.Items.Count - visibleItems + 1, 0);
            }
            catch (DirectoryNotFoundException)
            {
                log.Items.Add("오류: " + dir.FullName);
                log.TopIndex = Math.Max(log.Items.Count - visibleItems + 1, 0);
            }

            // 파일이 존재할 경우 아래를 실행

            if (files != null)
            {
                // 각 파일에 대하여 아래를 실행

                foreach (FileInfo fileinfo in files)
                {
                    // 각 파일에 대하여 아래를 실행

                    try
                    {
                        // 작업 대상 확장자가 아닌 경우 패스

                        if (!extensions.Contains(fileinfo.Extension.ToLower())) continue;

                        // 파일 크기가 3바이트 미만인 경우 UTF-8 BOM을 포함할 수 없으므로 패스

                        if (fileinfo.Length < 3) continue;

                        // 임시 파일명을 결정

                        string filename_original = fileinfo.FullName;
                        string filename_temp1 = filename_original + ".$BOM$" + DateTime.Now.ToString("yyyyMMddHHmmss") + "-TEMP";
                        string filename_temp2 = filename_original + ".$BOM$" + DateTime.Now.ToString("yyyyMMddHHmmss") + "-BACKUP";

                        // 원본 파일을 연다

                        FileStream fr = new FileStream(filename_original, FileMode.Open, FileAccess.Read);
                        BinaryReader frb = new BinaryReader(fr);

                        // 원본 파일에서 3바이트를 읽어들인다

                        byte[] first3bytes = frb.ReadBytes(3);

                        // 읽어들인 3바이트가 UTF-8 BOM인 경우 아래를 실행

                        if (first3bytes[0] == 0xEF && first3bytes[1] == 0xBB && first3bytes[2] == 0xBF)
                        {
                            // 로그에 기록

                            log.Items.Add(fileinfo.FullName);
                            log.TopIndex = Math.Max(log.Items.Count - visibleItems + 1, 0);

                            // 테스트 모드가 아닌 경우 아래를 실행

                            if (!testmode)
                            {
                                // 임시 파일을 연다

                                FileStream fw = new FileStream(filename_temp1, FileMode.CreateNew, FileAccess.Write);
                                BinaryWriter fwb = new BinaryWriter(fw);

                                // UTF-8 BOM을 제외하고 임시 파일에 기록

                                fwb.Write(frb.ReadBytes(Convert.ToInt32(fr.Length - 3)));

                                // 모든 파일을 닫는다

                                frb.Close();
                                fwb.Close();

                                // 원본 파일을 백업한 후 임시 파일을 원본으로 변경

                                File.Move(filename_original, filename_temp2);
                                File.Move(filename_temp1, filename_original);

                                // 모두 성공한 경우 백업파일 삭제

                                File.Delete(filename_temp2);
                            }

                            // 처리된 파일 수에 추가

                            processedItems++;
                        }
                    }
                    
                    // 예외 처리

                    catch (UnauthorizedAccessException)
                    {
                        log.Items.Add("접근 권한 없음: " + fileinfo.FullName);
                        log.TopIndex = Math.Max(log.Items.Count - visibleItems + 1, 0);
                    }
                    catch (FileNotFoundException)
                    {
                        log.Items.Add("오류: " + fileinfo.FullName);
                        log.TopIndex = Math.Max(log.Items.Count - visibleItems + 1, 0);
                    }
                    catch (IOException)
                    {
                        log.Items.Add("오류: " + fileinfo.FullName);
                        log.TopIndex = Math.Max(log.Items.Count - visibleItems + 1, 0);
                    }
                }
            }

            // 서브폴더 목록을 구한다

            try
            {
                subdirs = dir.GetDirectories();
            }

            // 예외 처리

            catch (UnauthorizedAccessException)
            {
                log.Items.Add("접근 권한 없음: " + dir.FullName);
                log.TopIndex = Math.Max(log.Items.Count - visibleItems + 1, 0);
            }
            catch (DirectoryNotFoundException)
            {
                log.Items.Add("오류: " + dir.FullName);
                log.TopIndex = Math.Max(log.Items.Count - visibleItems + 1, 0);
            }

            // 서브폴더가 존재할 경우 아래를 실행

            if (subdirs != null)
            {
                // 각 서브폴더에 대하여 아래를 실행

                foreach (DirectoryInfo dirinfo in subdirs)
                {
                    // NTFS 심볼릭 링크는 무한루프에 빠질 수 있으므로 건너뜀

                    if (dirinfo.Attributes.ToString().IndexOf("ReparsePoint") != -1)
                    {
                        log.Items.Add("건너뜀: " + dirinfo.FullName);
                        log.TopIndex = Math.Max(log.Items.Count - visibleItems + 1, 0);
                        continue;
                    }

                    // WalkDirectoryTree 함수를 다시 호출

                    processedItems += WalkDirectoryTree(dirinfo, extensions, status, log, testmode);
                }
            }

            // 처리된 파일 수를 반환

            return processedItems;
        }
    }
}
