﻿namespace BOM_Remover
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.Label_FolderName = new System.Windows.Forms.Label();
            this.FolderName = new System.Windows.Forms.TextBox();
            this.Button_FolderName = new System.Windows.Forms.Button();
            this.ActivityLog = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ExtensionList = new System.Windows.Forms.TextBox();
            this.Button_Start = new System.Windows.Forms.Button();
            this.StatusDisplay = new System.Windows.Forms.Label();
            this.IsTestMode = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // Label_FolderName
            // 
            this.Label_FolderName.AutoSize = true;
            this.Label_FolderName.Location = new System.Drawing.Point(12, 16);
            this.Label_FolderName.Name = "Label_FolderName";
            this.Label_FolderName.Size = new System.Drawing.Size(57, 12);
            this.Label_FolderName.TabIndex = 0;
            this.Label_FolderName.Text = "폴더 선택";
            // 
            // FolderName
            // 
            this.FolderName.Location = new System.Drawing.Point(77, 12);
            this.FolderName.Name = "FolderName";
            this.FolderName.Size = new System.Drawing.Size(585, 21);
            this.FolderName.TabIndex = 1;
            // 
            // Button_FolderName
            // 
            this.Button_FolderName.Location = new System.Drawing.Point(668, 12);
            this.Button_FolderName.Name = "Button_FolderName";
            this.Button_FolderName.Size = new System.Drawing.Size(25, 21);
            this.Button_FolderName.TabIndex = 2;
            this.Button_FolderName.Text = "...";
            this.Button_FolderName.UseVisualStyleBackColor = true;
            this.Button_FolderName.Click += new System.EventHandler(this.Button_FolderName_Click);
            // 
            // ActivityLog
            // 
            this.ActivityLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ActivityLog.FormattingEnabled = true;
            this.ActivityLog.IntegralHeight = false;
            this.ActivityLog.ItemHeight = 12;
            this.ActivityLog.Location = new System.Drawing.Point(-2, 69);
            this.ActivityLog.Name = "ActivityLog";
            this.ActivityLog.ScrollAlwaysVisible = true;
            this.ActivityLog.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.ActivityLog.Size = new System.Drawing.Size(788, 337);
            this.ActivityLog.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "확장자";
            // 
            // ExtensionList
            // 
            this.ExtensionList.Location = new System.Drawing.Point(77, 39);
            this.ExtensionList.Name = "ExtensionList";
            this.ExtensionList.Size = new System.Drawing.Size(550, 21);
            this.ExtensionList.TabIndex = 4;
            this.ExtensionList.Text = "php, inc, css, js, htm, html, phtml, shtml, xhtml, xml, asp, txt, csv, sql";
            // 
            // Button_Start
            // 
            this.Button_Start.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Start.Location = new System.Drawing.Point(699, 12);
            this.Button_Start.Name = "Button_Start";
            this.Button_Start.Size = new System.Drawing.Size(73, 48);
            this.Button_Start.TabIndex = 6;
            this.Button_Start.Text = "시작";
            this.Button_Start.UseVisualStyleBackColor = true;
            this.Button_Start.Click += new System.EventHandler(this.Button_Start_Click);
            // 
            // StatusDisplay
            // 
            this.StatusDisplay.Location = new System.Drawing.Point(12, 418);
            this.StatusDisplay.Name = "StatusDisplay";
            this.StatusDisplay.Size = new System.Drawing.Size(760, 13);
            this.StatusDisplay.TabIndex = 8;
            this.StatusDisplay.Text = "폴더를 선택하고 \"시작\"을 클릭하세요.";
            this.StatusDisplay.UseMnemonic = false;
            // 
            // IsTestMode
            // 
            this.IsTestMode.AutoSize = true;
            this.IsTestMode.BackColor = System.Drawing.Color.Transparent;
            this.IsTestMode.Location = new System.Drawing.Point(636, 42);
            this.IsTestMode.Name = "IsTestMode";
            this.IsTestMode.Size = new System.Drawing.Size(60, 16);
            this.IsTestMode.TabIndex = 5;
            this.IsTestMode.Text = "테스트";
            this.IsTestMode.UseVisualStyleBackColor = false;
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(784, 442);
            this.Controls.Add(this.IsTestMode);
            this.Controls.Add(this.StatusDisplay);
            this.Controls.Add(this.Button_Start);
            this.Controls.Add(this.ExtensionList);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ActivityLog);
            this.Controls.Add(this.Button_FolderName);
            this.Controls.Add(this.FolderName);
            this.Controls.Add(this.Label_FolderName);
            this.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(800, 480);
            this.MinimumSize = new System.Drawing.Size(800, 480);
            this.Name = "MainForm";
            this.Text = "BOM-Remover";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label_FolderName;
        private System.Windows.Forms.TextBox FolderName;
        private System.Windows.Forms.Button Button_FolderName;
        private System.Windows.Forms.ListBox ActivityLog;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ExtensionList;
        private System.Windows.Forms.Button Button_Start;
        private System.Windows.Forms.Label StatusDisplay;
        private System.Windows.Forms.CheckBox IsTestMode;
    }
}

