function openNav(){
	$("#i_navbar").toggle('clip');
}

function closeNav(){
	$("#i_navbar").toggle('clip');
	
	$("#i_spotkind").val('');
	$("#i_rectag-weight").val('-1');
	$("#i_tag").val('');
}